import json
from types import SimpleNamespace
import torch
from vllm_ascend_kvcompress.methods.base import CompressionRequest,LayerCache,ModelShape,QueryBatchSpan,QueryObservation
from vllm_ascend_kvcompress.transaction import CompressionPlan
from vllm_ascend_pyramidkv.method import PyramidKVMethod
from vllm_ascend_pyramidkv.shadow_check import install_shadow_check

torch.set_num_threads(2)
shape=ModelShape('qwen3_5_moe_text',40,16,2,256,1000000.,False,64,tuple(range(3,40,4)))
vconfig=SimpleNamespace(parallel_config=SimpleNamespace(tensor_parallel_size=2),speculative_config=SimpleNamespace(method='mtp',num_speculative_tokens=2))
config=json.load(open('/root/workspace/pyramidkv-config.json'))['method_config']
method=PyramidKVMethod(config,vconfig,shape)
cache=tuple(LayerCache(f'model.layers.{i}.self_attn.attn' if i<40 else 'mtp.layers.0.self_attn.attn',i,torch.randn(49,128,1,256,dtype=torch.bfloat16),torch.randn(49,128,1,256,dtype=torch.bfloat16)) for i in (*range(3,40,4),40))
method.bind_model_runner(SimpleNamespace(max_num_reqs=1,device=torch.device('cpu')),cache)
src=tuple(range(33));dst=tuple(range(33,49));plan=CompressionPlan(4097,2048,src,dst)
request=CompressionRequest('cpu-shadow-selftest',4097,4097,(src,),(dst,),torch.tensor(src,dtype=torch.int32),torch.tensor(dst,dtype=torch.int32),plan)
for layer in cache[:-1]: method.capture_query(layer,torch.randn(8,8,256,dtype=torch.bfloat16),(QueryBatchSpan(request.request_id,0,8),))
method.complete_query_observation(QueryObservation(request.request_id,plan,4097,8,shape.full_attention_layer_indices))
method.compress(request)
# Ensure the diagnostic detects an actual changed destination bit.
class Corrupt(PyramidKVMethod):
 def compress(self,req):
  result=super().compress(req)
  self.layer_caches[0].k_cache[33,0,0,0]=123
  return result
install_shadow_check(Corrupt)
bad=Corrupt.__new__(Corrupt);bad.__dict__.update(method.__dict__)
try: bad.compress(request)
except RuntimeError as e:
 assert 'shadow comparison differs' in str(e)
 print('PASS: real-method equality and injected corruption rejection')
else: raise AssertionError('Corruption was not detected')
