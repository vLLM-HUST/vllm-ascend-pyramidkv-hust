#!/usr/bin/env bash
set -eo pipefail
source /root/workspace/pyramidkv-runtime/env.sh
export VLLM_PLUGINS=ascend,ascend_model,ascend_model_loader,ascend_kv_connector
export VLLM_ASCEND_KVCOMPRESS_EXPERIMENTAL_MTP2=1
unset VLLM_ASCEND_KVCOMPRESS_ENABLED VLLM_ASCEND_KVCOMPRESS_CONFIG VLLMHUST_EXT_ENABLED_BUNDLES VLLM_EXTENSION_MANIFESTS VLLM_EXTENSION_BUNDLES
echo "$$" > /root/workspace/pyramidkv-runtime/server.pid
exec vllm-hust-ext run -- python -m vllm.entrypoints.cli.main serve /root/workspace/Qwen3.5-35B-A3B \
  --host 127.0.0.1 --port 8000 --served-model-name qwen35-pyramidkv \
  --tensor-parallel-size 2 --distributed-executor-backend mp --worker-cls pipeline_worker.Worker \
  --dtype bfloat16 --max-model-len 32768 \
  --max-num-seqs 4 --max-num-batched-tokens 4096 \
  --gpu-memory-utilization 0.9 --kv-cache-memory-bytes 8589934592 \
  --seed 17 --enable-prefix-caching --mamba-cache-mode align \
  --enable-chunked-prefill --async-scheduling --enable-prompt-tokens-details \
  --additional-config '{"enable_cpu_binding":false}' \
  --limit-mm-per-prompt '{"image":0,"video":0}' \
  --compilation-config '{"cudagraph_mode":"FULL_AND_PIECEWISE","cudagraph_capture_sizes":[3,6,12],"max_cudagraph_capture_size":12}' \
  --speculative-config '{"method":"mtp","num_speculative_tokens":2}' \
  --generation-config vllm "$@"
