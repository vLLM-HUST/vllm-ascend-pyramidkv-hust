import concurrent.futures,importlib.util,json,time,urllib.request
from pathlib import Path
root=Path('/root/workspace/pyramidkv-runtime/performance')
out=root/'shadow-serving';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('evaluate',root/'evaluate-salted.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
cases=json.loads(Path('/root/workspace/pyramidkv-runtime/evaluation/plan-extended/cases.json').read_text());lookup={c['case_id']:c for c in cases}
groups=[]
case=lookup['perf-24576-c1-r0-00']
for i in range(3): groups.append([{**case,'case_id':f'shadow-c1-repeat-{i}','cache_salt':f'shadow-c1-{i}'}])
for n in (8192,24576):
 groups.append([{**lookup[f'perf-{n}-c4-r0-{i:02d}'],'case_id':f'shadow-{n}-c4-{i}','cache_salt':f'shadow-{n}-{i}'} for i in range(4)])
groups.append([{**lookup[f'capacity-32704-c4-{i:02d}'],'case_id':f'shadow-32704-c4-{i}','cache_salt':f'shadow-capacity-{i}'} for i in range(4)])
for task in ('narrativeqa','qasper','2wikimqa'):
 c=next(c for c in cases if c.get('task')==task and c['prompt_tokens']>4096)
 groups.append([{**c,'case_id':f'shadow-quality-{task}','cache_salt':f'shadow-quality-{task}'}])
for i in range(2):groups.append([{**case,'case_id':f'shadow-apc-repeat-{i}','cache_salt':'shadow-apc-common'}])
(out/'plan.json').write_text(json.dumps({'scope':'same-real-cache diagnostic, no performance claim','groups':groups},indent=2)+'\n')
client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(600):
 try:
  with client.open('http://127.0.0.1:8000/health',timeout=1) as response:
   if response.status==200:break
 except OSError:pass
 time.sleep(2)
else:raise SystemExit('Readiness timeout; no requests sent')
results=[]
for group in groups:
 with concurrent.futures.ThreadPoolExecutor(max_workers=len(group)) as pool:
  for r in pool.map(lambda c:e.stream_request('http://127.0.0.1:8000',c,out),group):
   results.append(r); print(r['case_id'],r['success'],repr(r.get('output','')[:90]),flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 if not all(r['success'] for r in results):raise SystemExit('Request failed; inspect retained artifacts')
(out/'summary.json').write_text(json.dumps({'requests':len(results),'failures':sum(not r['success'] for r in results),'diagnostic_only':True,'c1_distinct_outputs':len({r['output'] for r in results[:3]})},indent=2)+'\n')
print('Shadow serving requests completed',flush=True)
