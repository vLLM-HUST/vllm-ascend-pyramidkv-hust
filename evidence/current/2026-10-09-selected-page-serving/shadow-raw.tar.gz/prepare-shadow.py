import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path('/root/workspace/pyramidkv-runtime/performance')
source=Path('/root/workspace/pyramidkv-perf/src/vllm_ascend_pyramidkv')
target=root/'shadow-src/vllm_ascend_pyramidkv'
if target.exists(): raise SystemExit('Shadow overlay already exists; inspect before replacing')
shutil.copytree(source,target,ignore=shutil.ignore_patterns('__pycache__'))
old=subprocess.check_output(['git','-C','/root/workspace/pyramidkv-perf','show','47580977a2dca108054470b3132811bd690020a6:src/vllm_ascend_pyramidkv/method.py'])
(target/'shadow_baseline.py').write_bytes(old)
wrapper='''
# Diagnostic overlay only: compare both implementations on the same real cache.
from vllm_ascend_pyramidkv.shadow_check import install_shadow_check
install_shadow_check(PyramidKVMethod)
'''
with (target/'method.py').open('a') as f: f.write(wrapper)
print(target)
