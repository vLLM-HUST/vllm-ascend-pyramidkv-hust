"""Diagnostic only; never use double compression for performance measurements."""
import hashlib
import json
import os
import time
from pathlib import Path

import torch
from vllm_ascend_pyramidkv.shadow_baseline import PyramidKVMethod as Baseline


def bits(tensor):
    return tensor.detach().contiguous().view(torch.int16).cpu()


def digest(tensor):
    return hashlib.sha256(tensor.numpy().tobytes()).hexdigest()


def install_shadow_check(candidate):
    original = candidate.compress

    def compress(self, request):
        reference = Baseline.__new__(Baseline)
        reference.__dict__.update(self.__dict__)
        count = (self.group_maximum + 127) // 128
        ids = request.destination_block_ids_device[:count].to(dtype=torch.long)
        source_count = (request.physical_num_tokens + 127) // 128
        sources = set(request.source_block_ids_device[:source_count].cpu().tolist())
        if sources.intersection(ids.cpu().tolist()):
            raise RuntimeError('Shadow diagnostic requires disjoint private destination pages')
        tensors = [(layer.name, kind, cache) for layer in self.materialization_caches
                   for kind, cache in [('k', layer.k_cache), ('v', layer.v_cache)]]
        initial = [cache.index_select(0, ids).clone() for _, _, cache in tensors]
        expected_result = reference.compress(request)
        expected = [bits(cache.index_select(0, ids)) for _, _, cache in tensors]
        for (_, _, cache), before in zip(tensors, initial):
            cache.index_copy_(0, ids, before)
        actual_result = original(self, request)
        checks = []
        for (name, kind, cache), expected_bits in zip(tensors, expected):
            actual_bits = bits(cache.index_select(0, ids))
            checks.append({'layer': name, 'kind': kind,
                           'shape': list(cache.shape), 'stride': list(cache.stride()),
                           'equal': torch.equal(expected_bits, actual_bits),
                           'expected_sha256': digest(expected_bits),
                           'actual_sha256': digest(actual_bits)})
        record = {'time': time.time(), 'pid': os.getpid(),
                  'device': str(tensors[0][2].device), 'request_id': request.request_id,
                  'semantic_num_tokens': request.semantic_num_tokens,
                  'physical_num_tokens': request.physical_num_tokens,
                  'destination_pages': count, 'result_equal': expected_result == actual_result,
                  'checks': checks, 'diagnostic_only': True}
        record['equal'] = record['result_equal'] and all(x['equal'] for x in checks)
        out = Path('/root/workspace/pyramidkv-runtime/performance/shadow-results')
        out.mkdir(exist_ok=True)
        with (out / f'worker-{os.getpid()}.jsonl').open('a') as f:
            f.write(json.dumps(record, sort_keys=True) + '\n')
        print('PYRAMIDKV_SHADOW ' + json.dumps({k:v for k,v in record.items() if k != 'checks'}), flush=True)
        if not record['equal']:
            raise RuntimeError('PyramidKV real-cache shadow comparison differs; refusing diagnostic commit')
        return actual_result

    candidate.compress = compress
